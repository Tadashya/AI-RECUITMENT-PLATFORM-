# TalentFlow AI

A full-stack career and recruitment MVP. The React dashboard includes a student career workspace, responsive layout, job recommendations, skill-gap cards, application tracking, and a resume upload experience. The Express REST API exposes JWT login, dashboard data, jobs, PDF upload analysis and interview-question endpoints.

## Local development

```powershell
npm install
npm run dev
```

Open `http://localhost:5173`; the API runs on `http://localhost:4000`.

## Deployment

Deploy `frontend` to Vercel with `VITE_API_URL=https://YOUR-API/api`, deploy `backend` as a Render Node service (`npm start`, root directory `backend`), and set `FRONTEND_URL` and `JWT_SECRET` in Render. Replace the in-memory data module with PostgreSQL/Prisma before production data use.
