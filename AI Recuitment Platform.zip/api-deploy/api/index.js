import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import multer from 'multer';

const app = express();
const secret = process.env.JWT_SECRET || 'talentflow-demo-secret';
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });
const jobs = [
  { id: 1, title: 'Frontend Engineer', company: 'Northstar Labs', location: 'Bengaluru · Hybrid', type: 'Full time', skills: ['React', 'TypeScript', 'Tailwind'], match: 91, applicants: 42 },
  { id: 2, title: 'Product Data Analyst', company: 'Orbit Commerce', location: 'Remote · India', type: 'Full time', skills: ['SQL', 'Python', 'Tableau'], match: 78, applicants: 31 },
  { id: 3, title: 'Junior AI Engineer', company: 'Verve AI', location: 'Mumbai · On-site', type: 'Full time', skills: ['Python', 'LLMs', 'FastAPI'], match: 72, applicants: 19 }
];
const candidate = { name: 'Aarav Sharma', role: 'Aspiring Software Engineer', completion: 82, skills: ['React', 'JavaScript', 'Node.js', 'Python', 'SQL', 'Git'], gaps: [{ skill: 'TypeScript', priority: 'High', progress: 24 }, { skill: 'System Design', priority: 'Medium', progress: 12 }, { skill: 'Docker', priority: 'Medium', progress: 38 }] };
app.use(cors()); app.use(express.json());
const guard = (req, res, next) => { try { req.user = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), secret); next(); } catch { res.status(401).json({ error: 'Authentication required' }); } };
app.get('/api/health', (_, res) => res.json({ status: 'ok', service: 'TalentFlow API' }));
app.post('/api/auth/login', (req, res) => { const { email = 'aarav@example.com', role = 'student' } = req.body; res.json({ token: jwt.sign({ email, role }, secret, { expiresIn: '7d' }), user: { email, role, name: role === 'recruiter' ? 'Maya Kapoor' : candidate.name } }); });
app.get('/api/dashboard', guard, (_, res) => res.json({ ...candidate, recommendedJobs: jobs, analytics: { applications: 12, interviews: 3, profileViews: 48, responseRate: 32 } }));
app.get('/api/jobs', (_, res) => res.json(jobs));
app.post('/api/resume', guard, upload.single('resume'), (req, res) => { if (!req.file) return res.status(400).json({ error: 'Please attach a PDF resume' }); if (req.file.mimetype !== 'application/pdf') return res.status(400).json({ error: 'Only PDF resumes are accepted' }); res.json({ fileName: req.file.originalname, analysis: { skills: candidate.skills, experience: '2 years', summary: 'Full-stack developer with strong React and Node.js foundations.', confidence: 0.91 } }); });
app.post('/api/interview/questions', guard, (req, res) => { const role = req.body.role || 'Software Engineer'; res.json({ role, questions: [`Walk me through a project most relevant to this ${role} role.`, 'How do you decide whether a component should own state?', 'Describe a difficult technical problem and how you solved it.', 'What would you improve in your last project with more time?'] }); });
export default app;
