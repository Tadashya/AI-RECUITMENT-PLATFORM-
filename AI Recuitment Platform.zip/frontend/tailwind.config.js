/** @type {import('tailwindcss').Config} */
export default { content: ['./index.html', './src/**/*.{js,jsx}'], theme: { extend: { colors: { ink: '#14213d', mint: '#dff7ef', coral: '#ff6b5e' }, boxShadow: { card: '0 12px 35px rgba(20,33,61,.08)' } } }, plugins: [] };
