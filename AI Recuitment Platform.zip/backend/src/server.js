import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import { jobs, candidate } from './data.js';

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });
app.use(cors({ origin: process.env.FRONTEND_URL?.split(',') || true }));
app.use(express.json());
const secret = process.env.JWT_SECRET || 'development-secret';
const tokenFor = (user) => jwt.sign(user, secret, { expiresIn: '7d' });
const guard = (req, res, next) => {
  try { req.user = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), secret); next(); }
  catch { res.status(401).json({ error: 'Authentication required' }); }
};

app.get('/api/health', (_, res) => res.json({ status: 'ok', service: 'TalentFlow API' }));
app.post('/api/auth/login', (req, res) => {
  const { email = 'aarav@example.com', role = 'student' } = req.body;
  res.json({ token: tokenFor({ email, role }), user: { email, role, name: role === 'recruiter' ? 'Maya Kapoor' : candidate.name } });
});
app.get('/api/dashboard', guard, (req, res) => res.json({ ...candidate, recommendedJobs: jobs, analytics: { applications: 12, interviews: 3, profileViews: 48, responseRate: 32 } }));
app.get('/api/jobs', (_, res) => res.json(jobs));
app.post('/api/jobs', guard, (req, res) => {
  if (req.user.role !== 'recruiter') return res.status(403).json({ error: 'Recruiter access required' });
  const job = { id: Date.now(), applicants: 0, posted: 'Just now', match: 0, ...req.body }; jobs.unshift(job); res.status(201).json(job);
});
app.post('/api/resume', guard, upload.single('resume'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Please attach a PDF resume' });
  if (req.file.mimetype !== 'application/pdf') return res.status(400).json({ error: 'Only PDF resumes are accepted' });
  res.json({ fileName: req.file.originalname, analysis: { skills: candidate.skills, experience: '2 years', summary: 'Full-stack developer with strong React and Node.js foundations.', confidence: 0.91 } });
});
app.post('/api/interview/questions', guard, (req, res) => {
  const role = req.body.role || 'Software Engineer';
  res.json({ role, questions: [`Walk me through a project most relevant to this ${role} role.`, 'How do you decide whether a component should own state?', 'Describe a difficult technical problem and how you solved it.', 'What would you improve in your last project with more time?'] });
});
app.get('/api/recruiter/overview', guard, (req, res) => res.json({ openJobs: jobs.length, totalCandidates: 92, interviews: 8, shortlisted: 14, jobs }));
app.listen(process.env.PORT || 4000, () => console.log(`TalentFlow API on :${process.env.PORT || 4000}`));
