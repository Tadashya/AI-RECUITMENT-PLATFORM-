export const jobs = [
  { id: 1, title: 'Frontend Engineer', company: 'Northstar Labs', location: 'Bengaluru · Hybrid', type: 'Full time', posted: '2d ago', salary: '₹12–18 LPA', skills: ['React', 'TypeScript', 'Tailwind'], match: 91, applicants: 42 },
  { id: 2, title: 'Product Data Analyst', company: 'Orbit Commerce', location: 'Remote · India', type: 'Full time', posted: '4d ago', salary: '₹9–14 LPA', skills: ['SQL', 'Python', 'Tableau'], match: 78, applicants: 31 },
  { id: 3, title: 'Junior AI Engineer', company: 'Verve AI', location: 'Mumbai · On-site', type: 'Full time', posted: '1w ago', salary: '₹10–16 LPA', skills: ['Python', 'LLMs', 'FastAPI'], match: 72, applicants: 19 }
];
export const candidate = {
  name: 'Aarav Sharma', role: 'Aspiring Software Engineer', completion: 82,
  skills: ['React', 'JavaScript', 'Node.js', 'Python', 'SQL', 'Git'],
  gaps: [{ skill: 'TypeScript', priority: 'High', progress: 24 }, { skill: 'System Design', priority: 'Medium', progress: 12 }, { skill: 'Docker', priority: 'Medium', progress: 38 }],
  applications: [{ id: 1, company: 'Northstar Labs', role: 'Frontend Engineer', status: 'Interview', date: 'Sep 18' }, { id: 2, company: 'Orbit Commerce', role: 'Data Analyst', status: 'Applied', date: 'Sep 16' }, { id: 3, company: 'Lumina', role: 'Software Intern', status: 'Review', date: 'Sep 12' }]
};
